# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 05-06-2019 by Guardian in Scrubs.

import re
from resources.lib.modules import cleantitle,client,source_utils


class source:
	def __init__(self):
		self.priority = 1
		self.language = ['en']
		self.genre_filter = ['animation', 'anime']
		self.domains = ['cartoonwire.to']
		self.base_link = 'https://cartoonwire.to'
		self.search_link = '/episode/%s-season-%s-episode-%s/'
		self.search_link2 = '/episode/%s-episode-%s/'
# https://watchcartoononline.info/zeroman/
# https://watchcartoononline.info/episode/zeroman-episode-13/


	def tvshow(self, imdb, tvdb, tvshowtitle, localtvshowtitle, aliases, year):
		try:
			url = cleantitle.geturl(tvshowtitle)
			return url
		except:
			return
 
 
	def episode(self, url, imdb, tvdb, title, premiered, season, episode):
		try:
			if not url: return
			tvshowtitle = url
			url = self.base_link + self.search_link % (tvshowtitle, season, episode)
			#url2 = self.base_link + self.search_link2 % (tvshowtitle, episode)
			return url
		except:
			return


	def sources(self, url, hostDict, hostprDict):
		sources = []
		if url == None: return sources
		try:
			r = client.request(url)
			try:
				match = re.compile('var filmId = "(.+?)"').findall(r)
				for film_id in match:
					server = 'vip'
					url = 'https://cartoonwire.to/ajax-get-link-stream/?server=' + server + '&filmId=' + film_id
					r = client.request(url)
					if r == '':
						pass
					else:
						quality = source_utils.check_url(r)
						r = client.request(r)
						match = re.compile('<iframe src="(.+?)"').findall(r)
						for url in match:
							sources.append({ 'source': server, 'quality': quality, 'language': 'en', 'url': url, 'direct': False, 'debridonly': False })
					server = 'streamango'
					url = 'https://cartoonwire.to/ajax-get-link-stream/?server=' + server + '&filmId=' + film_id
					r = client.request(url)
					if r == '':
						pass
					else:
						quality = source_utils.check_url(r)
						r = client.request(r)
						match = re.compile('<iframe src="(.+?)"').findall(r)
						for url in match:
							sources.append({ 'source': server, 'quality': quality, 'language': 'en', 'url': url, 'direct': False, 'debridonly': False })
					server = 'openload'
					url = 'https://cartoonwire.to/ajax-get-link-stream/?server=' + server + '&filmId=' + film_id
					r = client.request(url)
					if r == '':
						pass
					else:
						quality = source_utils.check_url(r)
						r = client.request(r)
						match = re.compile('<iframe src="(.+?)"').findall(r)
						for url in match:
							sources.append({ 'source': server, 'quality': quality, 'language': 'en', 'url': url, 'direct': False, 'debridonly': False })
					server = 'rapidvideo'
					url = 'https://cartoonwire.to/ajax-get-link-stream/?server=' + server + '&filmId=' + film_id
					r = client.request(url)
					if r == '':
						pass
					else:
						quality = source_utils.check_url(r)
						r = client.request(r)
						match = re.compile('<iframe src="(.+?)"').findall(r)
						for url in match:
							sources.append({ 'source': server, 'quality': quality, 'language': 'en', 'url': url, 'direct': False, 'debridonly': False })
					server = 'photo'
					url = 'https://cartoonwire.to/ajax-get-link-stream/?server=' + server + '&filmId=' + film_id
					r = client.request(url)
					if r == '':
						pass
					else:
						quality = source_utils.check_url(r)
						sources.append({ 'source': 'GDrive', 'quality': quality, 'language': 'en', 'url': r, 'direct': False, 'debridonly': False })
			except:
				return
		except Exception:
			return
		return sources


	def resolve(self, url):
		return url

