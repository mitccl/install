# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 05-06-2019 by Guardian in Scrubs.

import re,requests,urlparse
from resources.lib.modules import client,cleantitle,source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['moviescouch.xyz', 'moviescouch.pro', 'moviescouch.pw']
        self.base_link = 'https://moviescouch.xyz'
        self.search_link = '/?s=%s'
        self.headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36'}


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            search_id = cleantitle.getsearch(title)
            url = urlparse.urljoin(self.base_link, self.search_link)
            url = url  % (search_id.replace(':', ' ').replace(' ', '+'))
            search_results = client.request(url, headers=self.headers)
            match = re.compile('<article id=.+?href="(.+?)" title="(.+?)"',re.DOTALL).findall(search_results)
            for row_url, row_title in match:
                if cleantitle.get(title) in cleantitle.get(row_title):
                    if year in str(row_title):
                        return row_url
            return
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            if url == None:
                return sources
            #html = requests.get(url).content
            html = client.request(url, headers=self.headers)
            try:
                qual = re.compile('<li>Quality: (.+?)</li>').findall(html)
                for i in qual:
                    quality = source_utils.check_url(i)
                links = re.compile('<iframe src="(.+?)"',re.DOTALL).findall(html)
                for link in links:
                    host = link.split('//')[1].replace('www.','')
                    host = host.split('/')[0].split('.')[0].title()
                    valid, host = source_utils.is_host_valid(host, hostDict)
                    if 'gvideo' in host:
                        continue
                    if valid:
                        sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': link, 'direct': False, 'debridonly': False})
                return sources
            except:
                return
        except Exception:
            return
        return sources


    def resolve(self, url):
        return url

