# -*- coding: utf-8 -*-

'''
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os, base64, sys, urllib2, urlparse
import xbmc, xbmcaddon, xbmcgui

from resources.lib.modules import control
from resources.lib.modules import trakt
from resources.lib.modules import cache

sysaddon = sys.argv[0] ; syshandle = int(sys.argv[1])
artPath = control.artPath() ; addonFanart = control.addonFanart()

imdbCredentials = False if control.setting('imdb.user') == '' else True
traktCredentials = trakt.getTraktCredentialsInfo()
traktIndicators = trakt.getTraktIndicatorsInfo()

queueMenu = control.lang(32065).encode('utf-8')


class navigator:
    ADDON_ID      = xbmcaddon.Addon().getAddonInfo('id')
    HOMEPATH      = xbmc.translatePath('special://home/')
    ADDONSPATH    = os.path.join(HOMEPATH, 'addons')
    THISADDONPATH = os.path.join(ADDONSPATH, ADDON_ID)

    def root(self):
        self.addDirectoryItem('[COLOR FFd0cbd8][B]FILMS[/B][/COLOR]', 'movieNavigator', 'movies.png', 'DefaultMovies.png')
        self.addDirectoryItem('[COLOR FFd0cbd8][B]SHOWS[/B][/COLOR]', 'tvNavigator', 'tvshows.png', 'DefaultTVShows.png')
        self.addDirectoryItem('[COLOR FFd0cbd8][B]EXTENDED INFO[/B][/COLOR]', 'oneclick2Navigator', 'info.png', 'DefaultTVShows.png')
        #self.addDirectoryItem('[COLOR FFd0cbd8][B]SWIFT STREAMS[/B][/COLOR]', 'swiftNavigator', 'swift.png', 'swift.png')
        if self.getMenuEnabled('navi.channels') == True:
            self.addDirectoryItem('[COLOR FFd0cbd8][B]CHANNELS[/B][/COLOR]', 'channels', 'channels.png', 'DefaultMovies.png')
        if not control.setting('lists.widget') == '0':
            self.addDirectoryItem('[COLOR FFd0cbd8][B]MY FILMS[/B][/COLOR]', 'mymovieNavigator', 'mymovies.png', 'DefaultVideoPlaylists.png')
            self.addDirectoryItem('[COLOR FFd0cbd8][B]MY SHOWS[/B][/COLOR]', 'mytvNavigator', 'mytvshows.png', 'DefaultVideoPlaylists.png')
        if not control.setting('movie.widget') == '0':
            self.addDirectoryItem('[COLOR FFd0cbd8][B]LATEST FILMS[/B][/COLOR]', 'movieWidget', 'latest.png', 'DefaultRecentlyAddedMovies.png')
        if (traktIndicators == True and not control.setting('tv.widget.alt') == '0') or (traktIndicators == False and not control.setting('tv.widget') == '0'):
            self.addDirectoryItem('[COLOR FFd0cbd8][B]LATEST EPISODES[/B][/COLOR]', 'tvWidget', 'latest.png', 'DefaultRecentlyAddedEpisodes.png')
        if not control.setting('furk.api') == '':
            self.addDirectoryItem('Furk.net', 'furkNavigator', 'movies.png', 'movies.png')
        if self.getMenuEnabled('navi.docu') == True:
            self.addDirectoryItem('[COLOR FFd0cbd8][B]DOCUMENTARIES[/B][/COLOR]', 'docuHeaven', 'docs.png', 'DefaultMovies.png')
        self.addDirectoryItem('[COLOR FFd0cbd8][B]SEARCH[/B][/COLOR]', 'searchNavigator', 'search.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem('[COLOR FFd0cbd8][B]TOOLS[/B][/COLOR]', 'toolNavigator', 'tools.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem('[COLOR FFd0cbd8][B]OPENSCRAPER SETTINGS[/B][/COLOR]', 'openscrapersSettings&query=0.0', 'scraper.png', 'DefaultAddonProgram.png')
        downloads = True if control.setting('downloads') == 'true' and (len(control.listDir(control.setting('movie.download.path'))[0]) > 0 or len(control.listDir(control.setting('tv.download.path'))[0]) > 0) else False
        if downloads == True:
            self.addDirectoryItem(32009, 'downloadNavigator', 'downloads.png', 'DefaultAddonProgram.png')
        #self.addDirectoryItem('', '', 'tools.png', 'DefaultAddonProgram.png')
        self.endDirectory()

    def oneclick2(self):
        xbmc.executebuiltin('XBMC.RunScript(script.metalgearsolid)')  

        self.endDirectory()

    def furk(self):
        self.addDirectoryItem('User Files', 'furkUserFiles', 'DefaultTVShows.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Search', 'furkSearch', 'search.png', 'search.png')
        self.endDirectory()
    
    def getMenuEnabled(self, menu_title):
        is_enabled = control.setting(menu_title).strip()
        if (is_enabled == '' or is_enabled == 'false'): return False
        return True

    def movies(self, lite=False):
    	self.addDirectoryItem('[COLOR FFFFA500][B]===== MAIN SECTION =====[/B][/COLOR]', 'movies&url=U', 'movies.png', 'DefaultMovies.png')
        if self.getMenuEnabled('navi.moviegenre') == True:
            self.addDirectoryItem(32011, 'movieGenres', 'genres.png', 'DefaultMovies.png')
        if self.getMenuEnabled('navi.movieyears') == True:
            self.addDirectoryItem(32012, 'movieYears', 'years.png', 'DefaultMovies.png')
        if self.getMenuEnabled('navi.moviepersons') == True:
            self.addDirectoryItem(32013, 'moviePersons', 'people.png', 'DefaultMovies.png')
        if self.getMenuEnabled('navi.movielanguages') == True:
            self.addDirectoryItem(32014, 'movieLanguages', 'languages.png', 'DefaultMovies.png')
        if self.getMenuEnabled('navi.moviecerts') == True:
            self.addDirectoryItem(32015, 'movieCertificates', 'certificates.png', 'DefaultMovies.png')
        if self.getMenuEnabled('navi.movietrending') == True:
            self.addDirectoryItem(32017, 'movies&url=trending', 'people-watching.png', 'DefaultMovies.png')
        if self.getMenuEnabled('navi.moviepopular') == True:
            self.addDirectoryItem(32018, 'movies&url=popular', 'most-popular.png', 'DefaultMovies.png')
        if self.getMenuEnabled('navi.movieviews') == True:
            self.addDirectoryItem(32019, 'movies&url=views', 'most-voted.png', 'DefaultMovies.png')
        if self.getMenuEnabled('navi.movieboxoffice') == True:
            self.addDirectoryItem(32020, 'movies&url=boxoffice', 'box-office.png', 'DefaultMovies.png')
        if self.getMenuEnabled('navi.movieoscars') == True:
            self.addDirectoryItem(32021, 'movies&url=oscars', 'oscar-winners.png', 'DefaultMovies.png')
        if self.getMenuEnabled('navi.movietheaters') == True:
            self.addDirectoryItem(32022, 'movies&url=theaters', 'in-theaters.png', 'DefaultMovies.png')
        if self.getMenuEnabled('navi.moviewidget') == True:
            self.addDirectoryItem(32005, 'movieWidget', 'latest-movies.png', 'DefaultMovies.png')
        self.addDirectoryItem('[COLOR FFFFA500][B]===== END =====[/B][/COLOR]', 'movies&url=U', 'end.png', 'DefaultMovies.png')    
        self.addDirectoryItem('[COLOR FFFFA500][B]===== IMDB LISTS SECTION =====[/B][/COLOR]', 'movies&url=U', 'section.png', 'DefaultMovies.png')    
        self.addDirectoryItem('Hood/Gangster/Ghetto', 'movies&url=hood', 'hood.png', 'DefaultMovies.png')
        self.addDirectoryItem('Underlooked Horror', 'movies&url=under', 'under.png', 'DefaultMovies.png')
        self.addDirectoryItem('Found Footage', 'movies&url=found', 'found.png', 'DefaultMovies.png')  
        self.addDirectoryItem('Killer Bugs', 'movies&url=killerb', 'killerb.png', 'DefaultMovies.png')
        self.addDirectoryItem('Winter/Snow', 'movies&url=snow', 'snow.png', 'DefaultMovies.png') 
        self.addDirectoryItem('Haunted Houses', 'movies&url=house', 'house.png', 'DefaultMovies.png')
        self.addDirectoryItem('Prison', 'movies&url=prison', 'prison.png', 'DefaultMovies.png')
        self.addDirectoryItem('DVD And Bluray', 'movies&url=dvb', 'dvd.png', 'DefaultMovies.png')
        self.addDirectoryItem('Netflix Origionals', 'movies&url=nfoim', 'net.png', 'DefaultMovies.png')
        self.addDirectoryItem('IMDB Top 100', 'movies&url=top3', 'imdb.png', 'DefaultMovies.png')
        self.addDirectoryItem('IMDB Top 250', 'movies&url=top2', 'imdb.png', 'DefaultMovies.png')
        self.addDirectoryItem('IMDB Top 1000', 'movies&url=top4', 'imdb.png', 'DefaultMovies.png')
        self.addDirectoryItem('IMDB Best Director Winning', 'movies&url=bestd', 'imdb.png', 'DefaultMovies.png')
        self.addDirectoryItem('National Film Board Preserved ', 'movies&url=nfb', 'nat.png', 'DefaultMovies.png')
        self.addDirectoryItem('Fox', 'movies&url=fox', 'fox.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Paramount', 'movies&url=para', 'para.png', 'DefaultTVShows.png')
        self.addDirectoryItem('MGM', 'movies&url=pmgm', 'mgm.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Universal', 'movies&url=uni', 'uni.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Sony', 'movies&url=sony', 'sony.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Warner Bros', 'movies&url=warb', 'warb.png', 'DefaultTVShows.png')
        self.addDirectoryItem('IMDB Prime Video', 'movies&url=primev', 'imdb.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Classic', 'movies&url=classmov', 'classic.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Classic Horror', 'movies&url=classhor', 'classic.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Classic Fantasy', 'movies&url=classfant', 'classic.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Classic Western', 'movies&url=classwest', 'classic.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Classic Animation', 'movies&url=classani', 'classic.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Classic War', 'movies&url=classwar', 'classic.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Classic Sci-fi', 'movies&url=classsci', 'classic.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Eighties', 'movies&url=eighties', 'eighties.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Nineties', 'movies&url=nineties', 'nineties.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Noughties', 'movies&url=noughties', 'noughties.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Twenty Tens', 'movies&url=twentyten', 'tens.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Twenty Twentys', 'movies&url=twentytwen', 'twen.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Vampires', 'movies&url=vamp', 'vamp.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Monsters', 'movies&url=mon', 'mon.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Ufo/Alien', 'movies&url=ufoa', 'ufo.png', 'DefaultTVShows.png')
        self.addDirectoryItem('[COLOR FFFFA500][B]===== END =====[/B][/COLOR]', 'movies&url=U', 'end.png', 'DefaultMovies.png')
        self.addDirectoryItem('[COLOR FFFFA500][B]===== FAMILY SECTION =====[/B][/COLOR]', 'movies&url=U', 'section.png', 'DefaultMovies.png')
        self.addDirectoryItem('Ultimate Movie List', 'movies&url=ultimate', 'ult.png', 'DefaultMovies.png')
        self.addDirectoryItem('Boxsets', 'boxsetskidsNavigator', 'boxsets.png', 'DefaultMovies.png')
        self.addDirectoryItem('Top Rated Animated Movies', 'movies&url=top', 'anim.png', 'DefaultMovies.png')
        self.addDirectoryItem('Animation Vault', 'movies&url=vault', 'anim.png', 'DefaultRecentlyAddedEpisodes.png')
        self.addDirectoryItem('Musicals', 'movies&url=musicals', 'mus.png', 'DefaultMovies.png')
        self.addDirectoryItem('Lego', 'movies&url=lego', 'lego.png', 'DefaultMovies.png')
        self.addDirectoryItem('Most Popular Superhero Movies', 'movies&url=superpop', 'superhero.png', 'DefaultMovies.png')
        self.addDirectoryItem('DC & Marvel Movies', 'movies&url=superheromovies', 'superhero.png', 'DefaultMovies.png')
        self.addDirectoryItem('Marvel Movies', 'movies&url=marvelmovies', 'marvel.png', 'DefaultMovies.png')
        self.addDirectoryItem('DC Movies', 'movies&url=dcmovies', 'dc.png', 'DefaultMovies.png')
        self.addDirectoryItem('Marvel Animated Movies', 'movies&url=marvelanimate', 'marvel.png', 'DefaultMovies.png')
        self.addDirectoryItem('DC Animated Movies', 'movies&url=dcanimate', 'dc.png', 'DefaultMovies.png')
        self.addDirectoryItem('[COLOR FFFFA500][B]===== END =====[/B][/COLOR]', 'movies&url=U', 'end.png', 'DefaultMovies.png')
        self.addDirectoryItem('[COLOR FFFFA500][B]===== ANIME SECTION =====[/B][/COLOR]', 'movies&url=U', 'section.png', 'DefaultMovies.png')
        self.addDirectoryItem('Top 100 Anime', 'movies&url=top100a', 'anime.png', 'DefaultMovies.png')
        self.addDirectoryItem('[COLOR FFFFA500][B]===== END =====[/B][/COLOR]', 'movies&url=U', 'end.png', 'DefaultMovies.png')
        self.addDirectoryItem(32003, 'mymovieliteNavigator', 'mymovies.png', 'DefaultVideoPlaylists.png')
        self.addDirectoryItem(32028, 'moviePerson', 'people-search.png', 'DefaultMovies.png')
        self.addDirectoryItem(32010, 'movieSearch', 'search.png', 'DefaultMovies.png')
        
        self.endDirectory()

    def boxsetskids(self, lite=False):
        self.addDirectoryItem('3 Ninjas', 'movies&url=ninja', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Ace Ventura', 'movies&url=ace', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('The Addams Family', 'movies&url=addams', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Alice in Wonderland', 'movies&url=alice', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Alvin and the Chipmunks', 'movies&url=alvin', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Angry Birds', 'movies&url=birds', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Atlantis', 'movies&url=atlantis', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Back to the Future', 'movies&url=future', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('The Brave Little Toaster', 'movies&url=toaster', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Brother Bear', 'movies&url=bear', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Cars', 'movies&url=cars', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Chronicles of Narnia', 'movies&url=narnia', 'disney.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Cinderella', 'movies&url=cinderella', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Cloudy with a Chance of Meatballs', 'movies&url=cloudy', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Despicable Me', 'movies&url=despicable', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Diary of a Wimpy Kid', 'movies&url=wimpy', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Doctor Dolittle', 'movies&url=doctor', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Emperors New Groove', 'movies&url=emperor', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Fantastic Beasts', 'movies&url=beasts', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Finding Nemo', 'movies&url=nemo', 'boxsets.png', 'DefaultMovies.png')
        self.addDirectoryItem('The Flintstones', 'movies&url=flint', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Free Willy', 'movies&url=willy', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Frozen', 'movies&url=frozen', 'boxsets.png', 'DefaultMovies.png')
        self.addDirectoryItem('Ghostbusters', 'movies&url=ghostbusters', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('G.I. Joe', 'movies&url=gijoe', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Gnomeo & Juliet', 'movies&url=gnomes', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('A Goofy Movie', 'movies&url=goofy', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Goosebumps', 'movies&url=goosebumps', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Happy Feet', 'movies&url=feet', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Harry Potter', 'movies&url=harry', 'harry.png', 'DefaultMovies.png')
        self.addDirectoryItem('Honey, I Shrunk the Kids', 'movies&url=shrunk', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Hoodwinked', 'movies&url=hoodwinked', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Hotel Transylvania', 'movies&url=transylvania', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('How to Train Your Dragon', 'movies&url=dragon', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('The Hunger Games', 'movies&url=hunger', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Ice Age', 'movies&url=ice', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('The Incredibles', 'movies&url=incredibles', 'boxsets.png', 'DefaultMovies.png')
        self.addDirectoryItem('Indiana Jones', 'movies&url=indiana', 'boxsets.png', 'DefaultMovies.png')
        self.addDirectoryItem('Journey to the Center of the Earth', 'movies&url=journey', 'boxsets.png', 'DefaultMovies.png')
        self.addDirectoryItem('Jumanji', 'movies&url=jumanji', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Jurassic Park', 'movies&url=jurassic', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Kung Fu Panda', 'movies&url=panda', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Lady and the Tramp', 'movies&url=lady', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('The Land Before Time', 'movies&url=land', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Lilo & Stitch', 'movies&url=lilo', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('The Lion King', 'movies&url=king', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('The Lord of the Rings', 'movies&url=rings', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Madagascar', 'movies&url=mad', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Maleficent', 'movies&url=maleficent', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Men in Black', 'movies&url=mib', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('The Mighty Ducks', 'movies&url=ducks', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Minions', 'movies&url=minions', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Monsters, inc.', 'movies&url=monsters', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('The Mummy', 'movies&url=mummy', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Nanny McPhee', 'movies&url=nanny', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Night at the Museum', 'movies&url=museum', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Nut Job', 'movies&url=nut', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Open Season', 'movies&url=open', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Paddington Bear', 'movies&url=padd', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Percy Jackson', 'movies&url=percy', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Pirates of the Caribbean', 'movies&url=pirates', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Pitch Perfect', 'movies&url=pitch', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Planes', 'movies&url=planes', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Pokémon', 'movies&url=pokemon', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Rio', 'movies&url=rio', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('The Secret Life of Pets', 'movies&url=pets', 'boxsets.png', 'DefaultRecentlyAddedMovies.png') 
        self.addDirectoryItem('Shaun the Sheep', 'movies&url=sheep', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Sherlock Holmes', 'movies&url=sherlock', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Shrek', 'movies&url=shrek', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Snow White and the Huntsman', 'movies&url=huntsman', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Smurfs', 'movies&url=smurf', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Star Wars', 'movies&url=starwars', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Stuart Little', 'movies&url=little', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Surfs Up', 'movies&url=surf', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Tarzan', 'movies&url=tarzan', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Tinker Bell', 'movies&url=tinker', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('TMNT', 'movies&url=tmnt', 'tmnt.png', 'DefaultRecentlyAddedMovies.png')
        self.addDirectoryItem('Toy Story', 'movies&url=toystory', 'boxsets.png', 'DefaultMovies.png')
        self.addDirectoryItem('Transformers', 'movies&url&url=robots', 'transformers.png', 'DefaultMovies.png')
        self.addDirectoryItem('Twilight', 'movies&url&url=wolf', 'boxsets.png', 'DefaultMovies.png')
        self.addDirectoryItem('Wreck it Ralph', 'movies&url=ralph', 'boxsets.png', 'DefaultRecentlyAddedMovies.png')

        self.endDirectory()
   
    def mymovies(self, lite=False):
        self.accountCheck()
        self.addDirectoryItem(32039, 'movieUserlists', 'userlists.png', 'DefaultMovies.png')
        if traktCredentials == True and imdbCredentials == True:
            self.addDirectoryItem(32032, 'movies&url=traktcollection', 'trakt.png', 'DefaultMovies.png', queue=True, context=(32551, 'moviesToLibrary&url=traktcollection'))
            self.addDirectoryItem(32033, 'movies&url=traktwatchlist', 'trakt.png', 'DefaultMovies.png', queue=True, context=(32551, 'moviesToLibrary&url=traktwatchlist'))
            if traktIndicators == True:
                self.addDirectoryItem(32036, 'movies&url=trakthistory', 'trakt.png', 'DefaultMovies.png', queue=True)
            self.addDirectoryItem(32035, 'movies&url=traktfeatured', 'trakt.png', 'DefaultMovies.png', queue=True)
#            self.addDirectoryItem(32034, 'movies&url=imdbwatchlist', 'imdb.png', 'DefaultMovies.png', queue=True)
            self.addDirectoryItem(32033, 'movies&url=imdbwatchlist2', 'imdb.png', 'DefaultMovies.png', queue=True)
            self.addDirectoryItem(32035, 'movies&url=featured', 'imdb.png', 'DefaultMovies.png', queue=True)
        elif traktCredentials == True:
            self.addDirectoryItem(32032, 'movies&url=traktcollection', 'trakt.png', 'DefaultMovies.png', queue=True, context=(32551, 'moviesToLibrary&url=traktcollection'))
            self.addDirectoryItem(32033, 'movies&url=traktwatchlist', 'trakt.png', 'DefaultMovies.png', queue=True, context=(32551, 'moviesToLibrary&url=traktwatchlist'))
            if traktIndicators == True:
                self.addDirectoryItem(32036, 'movies&url=trakthistory', 'trakt.png', 'DefaultMovies.png', queue=True)
            self.addDirectoryItem(32035, 'movies&url=traktfeatured', 'trakt.png', 'DefaultMovies.png', queue=True)
        elif imdbCredentials == True:
#            self.addDirectoryItem(32032, 'movies&url=imdbwatchlist', 'imdb.png', 'DefaultMovies.png', queue=True)
            self.addDirectoryItem(32033, 'movies&url=imdbwatchlist2', 'imdb.png', 'DefaultMovies.png', queue=True)
            self.addDirectoryItem(32035, 'movies&url=featured', 'imdb.png', 'DefaultMovies.png', queue=True)
        if lite == False:
            self.addDirectoryItem(32031, 'movieliteNavigator', 'movies.png', 'DefaultMovies.png')
            self.addDirectoryItem(32028, 'moviePerson', 'people-search.png', 'DefaultMovies.png')
            self.addDirectoryItem(32010, 'movieSearch', 'search.png', 'DefaultMovies.png')
        self.endDirectory()

    def tvshows(self, lite=False):
    	self.addDirectoryItem('[COLOR FFFFA500][B]===== MAIN SECTION =====[/B][/COLOR]', 'movies&url=U', 'movies.png', 'DefaultMovies.png')
        if self.getMenuEnabled('navi.tvGenres') == True:
            self.addDirectoryItem(32011, 'tvGenres', 'genres.png', 'DefaultTVShows.png')
        if self.getMenuEnabled('navi.tvNetworks') == True:
            self.addDirectoryItem(32016, 'tvNetworks', 'networks.png', 'DefaultTVShows.png')
        if self.getMenuEnabled('navi.tvLanguages') == True:
            self.addDirectoryItem(32014, 'tvLanguages', 'languages.png', 'DefaultTVShows.png')
        if self.getMenuEnabled('navi.tvCertificates') == True:
            self.addDirectoryItem(32015, 'tvCertificates', 'certificates.png', 'DefaultTVShows.png')
        if self.getMenuEnabled('navi.tvTrending') == True:
            self.addDirectoryItem(32017, 'tvshows&url=trending', 'people-watching.png', 'DefaultRecentlyAddedEpisodes.png')
        if self.getMenuEnabled('navi.tvPopular') == True:
            self.addDirectoryItem(32018, 'tvshows&url=popular', 'most-popular.png', 'DefaultTVShows.png')
        if self.getMenuEnabled('navi.tvRating') == True:
            self.addDirectoryItem(32023, 'tvshows&url=rating', 'highly-rated.png', 'DefaultTVShows.png')
        if self.getMenuEnabled('navi.tvViews') == True:
            self.addDirectoryItem(32019, 'tvshows&url=views', 'most-voted.png', 'DefaultTVShows.png')
        if self.getMenuEnabled('navi.tvAiring') == True:
            self.addDirectoryItem(32024, 'tvshows&url=airing', 'airing-today.png', 'DefaultTVShows.png')
        if self.getMenuEnabled('navi.tvActive') == True:
            self.addDirectoryItem(32025, 'tvshows&url=active', 'returning-tvshows.png', 'DefaultTVShows.png')
        if self.getMenuEnabled('navi.tvPremier') == True:
            self.addDirectoryItem(32026, 'tvshows&url=premiere', 'new-tvshows.png', 'DefaultTVShows.png')
        if self.getMenuEnabled('navi.tvAdded') == True:
            self.addDirectoryItem(32006, 'calendar&url=added', 'latest-episodes.png', 'DefaultRecentlyAddedEpisodes.png', queue=True)
        if self.getMenuEnabled('navi.tvCalendar') == True:
            self.addDirectoryItem(32027, 'calendars', 'calendar.png', 'DefaultRecentlyAddedEpisodes.png')
        self.addDirectoryItem('[COLOR FFFFA500][B]===== END =====[/B][/COLOR]', 'movies&url=U', 'end.png', 'DefaultMovies.png')
        self.addDirectoryItem('[COLOR FFFFA500][B]===== IMDB LISTS SECTION =====[/B][/COLOR]', 'movies&url=U', 'movies.png', 'DefaultMovies.png')
        self.addDirectoryItem('IMDB Prime Video', 'tvshows&url=usprime', 'imdb.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Documentaries', 'tvshows&url=docsa', 'docs.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Mystery', 'tvshows&url=myst', 'myst.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Sci-Fi', 'tvshows&url=scifi1', 'scifi.png', 'DefaultTVShows.png')
        self.addDirectoryItem('User Rating 7 to 10', 'tvshows&url=userr', 'highly-rated.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Mini-Series', 'tvshows&url=mini', 'mini.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Classic', 'tvshows&url=classtv', 'classic.png', 'DefaultTVShows.png')
        self.addDirectoryItem('PG-PG13', 'tvshows&url=pg', 'pg.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Sci-Fi Animation', 'tvshows&url=scian', 'scifi.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Global Animation', 'tvshows&url=ani1', 'glob.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Reality TV', 'tvshows&url=rtv', 'real.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Walt Disney', 'tvshows&url=waltd', 'dis.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Sony', 'tvshows&url=sony3', 'sony.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Warner Bros', 'tvshows&url=warnerbro1', 'warb.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Universal', 'tvshows&url=uni1', 'uni.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Fox', 'tvshows&url=fox11', 'fox.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Paramount', 'tvshows&url=para4', 'para.png', 'DefaultTVShows.png')
        self.addDirectoryItem('MGM', 'tvshows&url=mgm5', 'mgm.png', 'DefaultTVShows.png')
        self.addDirectoryItem('[COLOR FFFFA500][B]===== END =====[/B][/COLOR]', 'movies&url=U', 'end.png', 'DefaultMovies.png')
        self.addDirectoryItem('[COLOR FFFFA500][B]===== FAMILY SECTION =====[/B][/COLOR]', 'movies&url=U', 'movies.png', 'DefaultMovies.png')
        self.addDirectoryItem('Popular Cartoons', 'tvshows&url=popular', 'most-popular.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Trending Shows', 'tvshows&url=views', 'trending.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Most Popular Superhero TV Series', 'tvshows&url=pophero', 'superhero.png', 'DefaulTVShows.png')
        self.addDirectoryItem('Highest Rated Family TV Series', 'tvshows&url=high', 'highly-rated.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Teen TV Networks', 'teentvNavigator', 'networks.png', 'DefaulTVShows.png') 
        self.addDirectoryItem('Popular Networks', 'kidNetworks', 'networks.png', 'DefaulTVShows.png')
        self.addDirectoryItem('Throwbackback TV', 'tvshows&url=retrotv', 'retro.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Lego TV', 'tvshows&url=lego', 'lego.png', 'DefaulTVShows.png')
        self.addDirectoryItem('Transformers TV', 'tvshows&url=robots', 'cyber.png', 'DefaulTVShows.png')
        self.addDirectoryItem('Disney Jr Shows', 'tvshows&url=disneyjr', 'dis.png', 'DefaulTVShows.png')
        self.addDirectoryItem('Nick Jr Shows', 'tvshows&url=nickjr', 'nick.png', 'DefaulTVShows.png')
        self.addDirectoryItem('Netflix Shows', 'tvshows&url=netflixkid', 'net.png', 'DefaulTVShows.png')
        self.addDirectoryItem('Random Toddler Shows', 'tvshows&url=toddler', 'toddler.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Disney Channel', 'tvshows&url=disneychannel', 'dis.png', 'DefaulTVShows.png')
        self.addDirectoryItem('Teen Nick', 'tvshows&url=teennick', 'teen.png', 'DefualtTVshows.png')
        self.addDirectoryItem('Teen TV Shows', 'tvshows&url=teentv', 'teen.png', 'DefualtTVshows.png')
        self.addDirectoryItem('Nickelodeon', 'tvshows&url=nick', 'nick.png', 'DefaultTVShows.png')
        self.addDirectoryItem('Cartoon Network', 'tvshows&url=cartoonnetwork', 'cart.png', 'DefualtTVshows.png')
        self.addDirectoryItem('Nicktoons', 'tvshows&url=nicktoons', 'nick.png', 'DefualtTVshows.png')
        self.addDirectoryItem('Disney XD', 'tvshows&url=disneyxd', 'dis.png', 'DefualtTVshows.png')
        self.addDirectoryItem('[COLOR FFFFA500][B]===== END =====[/B][/COLOR]', 'movies&url=U', 'end.png', 'DefaultMovies.png')
        self.addDirectoryItem(32004, 'mytvliteNavigator', 'mytvshows.png', 'DefaultVideoPlaylists.png')
        self.addDirectoryItem(32028, 'tvPerson', 'people-search.png', 'DefaultTVShows.png')
        self.addDirectoryItem(32010, 'tvSearch', 'search.png', 'DefaultTVShows.png')
        
        self.endDirectory()

    def mytvshows(self, lite=False):
        self.accountCheck()
        self.addDirectoryItem(32040, 'tvUserlists', 'userlists.png', 'DefaultTVShows.png')
        if traktCredentials == True and imdbCredentials == True:
            self.addDirectoryItem(32032, 'tvshows&url=traktcollection', 'trakt.png', 'DefaultTVShows.png', context=(32551, 'tvshowsToLibrary&url=traktcollection'))
            self.addDirectoryItem(32033, 'tvshows&url=traktwatchlist', 'trakt.png', 'DefaultTVShows.png', context=(32551, 'tvshowsToLibrary&url=traktwatchlist'))
            self.addDirectoryItem(32041, 'episodeUserlists', 'trakt.png', 'DefaultTVShows.png')
            self.addDirectoryItem(32035, 'tvshows&url=traktfeatured', 'trakt.png', 'DefaultTVShows.png')
            if traktIndicators == True:
                self.addDirectoryItem(32036, 'calendar&url=trakthistory', 'trakt.png', 'DefaultTVShows.png', queue=True)
                self.addDirectoryItem(32037, 'calendar&url=progress', 'trakt.png', 'DefaultRecentlyAddedEpisodes.png', queue=True)
                self.addDirectoryItem(32038, 'calendar&url=mycalendar', 'trakt.png', 'DefaultRecentlyAddedEpisodes.png', queue=True)
#            self.addDirectoryItem(32032, 'tvshows&url=imdbwatchlist', 'imdb.png', 'DefaultTVShows.png')
            self.addDirectoryItem(32033, 'tvshows&url=imdbwatchlist2', 'imdb.png', 'DefaultTVShows.png')
            self.addDirectoryItem(32035, 'tvshows&url=trending', 'imdb.png', 'DefaultMovies.png', queue=True)
        elif traktCredentials == True:
            self.addDirectoryItem(32032, 'tvshows&url=traktcollection', 'trakt.png', 'DefaultTVShows.png', context=(32551, 'tvshowsToLibrary&url=traktcollection'))
            self.addDirectoryItem(32033, 'tvshows&url=traktwatchlist', 'trakt.png', 'DefaultTVShows.png', context=(32551, 'tvshowsToLibrary&url=traktwatchlist'))
            self.addDirectoryItem(32041, 'episodeUserlists', 'userlists.png', 'DefaultTVShows.png')
            self.addDirectoryItem(32035, 'tvshows&url=traktfeatured', 'trakt.png', 'DefaultTVShows.png')
            if traktIndicators == True:
                self.addDirectoryItem(32036, 'calendar&url=trakthistory', 'trakt.png', 'DefaultTVShows.png', queue=True)
                self.addDirectoryItem(32037, 'calendar&url=progress', 'trakt.png', 'DefaultRecentlyAddedEpisodes.png', queue=True)
                self.addDirectoryItem(32038, 'calendar&url=mycalendar', 'trakt.png', 'DefaultRecentlyAddedEpisodes.png', queue=True)
        elif imdbCredentials == True:
#            self.addDirectoryItem(32032, 'tvshows&url=imdbwatchlist', 'imdb.png', 'DefaultTVShows.png')
            self.addDirectoryItem(32033, 'tvshows&url=imdbwatchlist2', 'imdb.png', 'DefaultTVShows.png')
            self.addDirectoryItem(32035, 'tvshows&url=trending', 'imdb.png', 'DefaultMovies.png', queue=True)

        if lite == False:
            self.addDirectoryItem(32031, 'tvliteNavigator', 'tvshows.png', 'DefaultTVShows.png')
            self.addDirectoryItem(32028, 'tvPerson', 'people-search.png', 'DefaultTVShows.png')
            self.addDirectoryItem(32010, 'tvSearch', 'search.png', 'DefaultTVShows.png')
        self.endDirectory()

    def tools(self):
        self.addDirectoryItem(32043, 'openSettings&query=0.0', 'tools.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem(32628, 'openSettings&query=1.0', 'tools.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem(32045, 'openSettings&query=2.0', 'tools.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem(32047, 'openSettings&query=3.0', 'tools.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem(32044, 'openSettings&query=4.1', 'tools.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem(32046, 'openSettings&query=7.0', 'tools.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem(32048, 'openSettings&query=6.0', 'tools.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem(32556, 'libraryNavigator', 'tools.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem(32049, 'viewsNavigator', 'tools.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem('Cache Functions', 'cfNavigator', 'tools.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem(32073, 'authTrakt', 'trakt.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem(32609, 'urlResolver', 'urlresolver.png', 'DefaultAddonProgram.png')
        self.endDirectory()


    def cf(self):
        self.addDirectoryItem(32050, 'clearSources', 'tools.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem(32604, 'clearCacheSearch', 'tools.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem(32052, 'clearCache', 'tools.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem(32614, 'clearMetaCache', 'tools.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem(32613, 'clearAllCache', 'tools.png', 'DefaultAddonProgram.png')
        self.endDirectory()


    def library(self):
        self.addDirectoryItem(32557, 'openSettings&query=5.0', 'tools.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem(32558, 'updateLibrary&query=tool', 'library_update.png', 'DefaultAddonProgram.png')
        self.addDirectoryItem(32559, control.setting('library.movie'), 'movies.png', 'DefaultMovies.png', isAction=False)
        self.addDirectoryItem(32560, control.setting('library.tv'), 'tvshows.png', 'DefaultTVShows.png', isAction=False)
        if trakt.getTraktCredentialsInfo():
            self.addDirectoryItem(32561, 'moviesToLibrary&url=traktcollection', 'trakt.png', 'DefaultMovies.png')
            self.addDirectoryItem(32562, 'moviesToLibrary&url=traktwatchlist', 'trakt.png', 'DefaultMovies.png')
            self.addDirectoryItem(32563, 'tvshowsToLibrary&url=traktcollection', 'trakt.png', 'DefaultTVShows.png')
            self.addDirectoryItem(32564, 'tvshowsToLibrary&url=traktwatchlist', 'trakt.png', 'DefaultTVShows.png')
        self.endDirectory()

    def downloads(self):
        movie_downloads = control.setting('movie.download.path')
        tv_downloads = control.setting('tv.download.path')
        if len(control.listDir(movie_downloads)[0]) > 0:
            self.addDirectoryItem(32001, movie_downloads, 'movies.png', 'DefaultMovies.png', isAction=False)
        if len(control.listDir(tv_downloads)[0]) > 0:
            self.addDirectoryItem(32002, tv_downloads, 'tvshows.png', 'DefaultTVShows.png', isAction=False)
        self.endDirectory()

    def search(self):
        self.addDirectoryItem(32001, 'movieSearch', 'search.png', 'DefaultMovies.png')
        self.addDirectoryItem(32002, 'tvSearch', 'search.png', 'DefaultTVShows.png')
        self.addDirectoryItem(32029, 'moviePerson', 'people-search.png', 'DefaultMovies.png')
        self.addDirectoryItem(32030, 'tvPerson', 'people-search.png', 'DefaultTVShows.png')
        self.endDirectory()

    def views(self):
        try:
            control.idle()
            items = [ (control.lang(32001).encode('utf-8'), 'movies'), (control.lang(32002).encode('utf-8'), 'tvshows'), (control.lang(32054).encode('utf-8'), 'seasons'), (control.lang(32038).encode('utf-8'), 'episodes') ]
            select = control.selectDialog([i[0] for i in items], control.lang(32049).encode('utf-8'))
            if select == -1: return
            content = items[select][1]
            title = control.lang(32059).encode('utf-8')
            url = '%s?action=addView&content=%s' % (sys.argv[0], content)
            poster, banner, fanart = control.addonPoster(), control.addonBanner(), control.addonFanart()
            item = control.item(label=title)
            item.setInfo(type='Video', infoLabels = {'title': title})
            item.setArt({'icon': poster, 'thumb': poster, 'poster': poster, 'banner': banner})
            item.setProperty('Fanart_Image', fanart)
            control.addItem(handle=int(sys.argv[1]), url=url, listitem=item, isFolder=False)
            control.content(int(sys.argv[1]), content)
            control.directory(int(sys.argv[1]), cacheToDisc=True)
            from resources.lib.modules import views
            views.setView(content, {})
        except:
            return

    def accountCheck(self):
        if traktCredentials == False and imdbCredentials == False:
            control.idle()
            control.infoDialog(control.lang(32042).encode('utf-8'), sound=True, icon='WARNING')
            sys.exit()

    def infoCheck(self, version):
        try:
            control.infoDialog('', control.lang(32074).encode('utf-8'), time=5000, sound=False)
            return '1'
        except:
            return '1'

    def clearCache(self):
        control.idle()
        yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
        if not yes: return
        from resources.lib.modules import cache
        cache.cache_clear()
        control.infoDialog(control.lang(32057).encode('utf-8'), sound=True, icon='INFO')

    def clearCacheMeta(self):
        control.idle()
        yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
        if not yes: return
        from resources.lib.modules import cache
        cache.cache_clear_meta()
        control.infoDialog(control.lang(32057).encode('utf-8'), sound=True, icon='INFO')

    def clearCacheProviders(self):
        control.idle()
        yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
        if not yes: return
        from resources.lib.modules import cache
        cache.cache_clear_providers()
        control.infoDialog(control.lang(32057).encode('utf-8'), sound=True, icon='INFO')

    def clearCacheSearch(self):
        control.idle()
        if control.yesnoDialog(control.lang(32056).encode('utf-8'), '', ''):
            control.setSetting('tvsearch', '')
            control.setSetting('moviesearch', '')
            control.refresh()

    def clearCacheAll(self):
        control.idle()
        yes = control.yesnoDialog(control.lang(32056).encode('utf-8'), '', '')
        if not yes: return
        from resources.lib.modules import cache
        cache.cache_clear_all()
        control.infoDialog(control.lang(32057).encode('utf-8'), sound=True, icon='INFO')

    def addDirectoryItem(self, name, query, thumb, icon, context=None, queue=False, isAction=True, isFolder=True):
        try: name = control.lang(name).encode('utf-8')
        except: pass
        url = '%s?action=%s' % (sysaddon, query) if isAction == True else query
        thumb = os.path.join(artPath, thumb) if not artPath == None else icon
        cm = []
        cm.append(('devil_dogg Settings', 'RunPlugin(%s?action=openSettings&query=(0,0))' % sysaddon))
        if queue == True: cm.append((queueMenu, 'RunPlugin(%s?action=queueItem)' % sysaddon))
        if not context == None: cm.append((control.lang(context[0]).encode('utf-8'), 'RunPlugin(%s?action=%s)' % (sysaddon, context[1])))
        item = control.item(label=name)
        item.addContextMenuItems(cm)
        item.setArt({'icon': thumb, 'thumb': thumb})
        if not addonFanart == None: item.setProperty('Fanart_Image', addonFanart)
        control.addItem(handle=syshandle, url=url, listitem=item, isFolder=isFolder)

    def endDirectory(self):
        control.content(syshandle, 'addons')
        control.directory(syshandle, cacheToDisc=True)
